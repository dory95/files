
insert overwrite table engine_data_hive
select
orgseq,
vehiclemodelseq,
vehicleseq,
districtseq,
datatime,
enginefuelconsumptionrate
from engine_data;

insert overwrite table motor_data_hive
select
orgseq,
vehiclemodelseq,
vehicleseq,
districtseq,
datatime,
CtrollerTmp,
RotatingSpeed,
temperature,
controllerCurrent
from motor_data;

insert overwrite table vehicle_data_hive
select
orgseq,
vehiclemodelseq,
vehicleseq,
districtseq,
datatime,
sumMileage,
speed,
vehicleStatus,
SOC,
insulationResistance
from vehicle_data;

insert overwrite table vehicle_position_hive
select
orgseq,
vehiclemodelseq,
vehicleseq,
districtseq,
datatime,
latitude,
locationState,
longitude
from vehicle_position;

insert overwrite table extreme_value_hive
select
orgseq,
vehiclemodelseq,
vehicleseq,
districtseq,
datatime,
maxTmpVal,
minTmpVal,
maxBatterySingleVoltageVal,
minBatterySingleVoltageVal
from extreme_value;

