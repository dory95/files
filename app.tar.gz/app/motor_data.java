// ORM class for table 'motor_data'
// WARNING: This class is AUTO-GENERATED. Modify at your own risk.
//
// Debug information:
// Generated date: Sun Jan 28 02:20:04 CST 2018
// For connector: org.apache.sqoop.manager.MySQLManager
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapred.lib.db.DBWritable;
import com.cloudera.sqoop.lib.JdbcWritableBridge;
import com.cloudera.sqoop.lib.DelimiterSet;
import com.cloudera.sqoop.lib.FieldFormatter;
import com.cloudera.sqoop.lib.RecordParser;
import com.cloudera.sqoop.lib.BooleanParser;
import com.cloudera.sqoop.lib.BlobRef;
import com.cloudera.sqoop.lib.ClobRef;
import com.cloudera.sqoop.lib.LargeObjectLoader;
import com.cloudera.sqoop.lib.SqoopRecord;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class motor_data extends SqoopRecord  implements DBWritable, Writable {
  private final int PROTOCOL_VERSION = 3;
  public int getClassFormatVersion() { return PROTOCOL_VERSION; }
  protected ResultSet __cur_result_set;
  private Integer orgseq;
  public Integer get_orgseq() {
    return orgseq;
  }
  public void set_orgseq(Integer orgseq) {
    this.orgseq = orgseq;
  }
  public motor_data with_orgseq(Integer orgseq) {
    this.orgseq = orgseq;
    return this;
  }
  private Integer vehiclemodelseq;
  public Integer get_vehiclemodelseq() {
    return vehiclemodelseq;
  }
  public void set_vehiclemodelseq(Integer vehiclemodelseq) {
    this.vehiclemodelseq = vehiclemodelseq;
  }
  public motor_data with_vehiclemodelseq(Integer vehiclemodelseq) {
    this.vehiclemodelseq = vehiclemodelseq;
    return this;
  }
  private Long vehicleseq;
  public Long get_vehicleseq() {
    return vehicleseq;
  }
  public void set_vehicleseq(Long vehicleseq) {
    this.vehicleseq = vehicleseq;
  }
  public motor_data with_vehicleseq(Long vehicleseq) {
    this.vehicleseq = vehicleseq;
    return this;
  }
  private Integer districtseq;
  public Integer get_districtseq() {
    return districtseq;
  }
  public void set_districtseq(Integer districtseq) {
    this.districtseq = districtseq;
  }
  public motor_data with_districtseq(Integer districtseq) {
    this.districtseq = districtseq;
    return this;
  }
  private java.sql.Timestamp datatime;
  public java.sql.Timestamp get_datatime() {
    return datatime;
  }
  public void set_datatime(java.sql.Timestamp datatime) {
    this.datatime = datatime;
  }
  public motor_data with_datatime(java.sql.Timestamp datatime) {
    this.datatime = datatime;
    return this;
  }
  private Integer ctrollertmp;
  public Integer get_ctrollertmp() {
    return ctrollertmp;
  }
  public void set_ctrollertmp(Integer ctrollertmp) {
    this.ctrollertmp = ctrollertmp;
  }
  public motor_data with_ctrollertmp(Integer ctrollertmp) {
    this.ctrollertmp = ctrollertmp;
    return this;
  }
  private Integer rotatingspeed;
  public Integer get_rotatingspeed() {
    return rotatingspeed;
  }
  public void set_rotatingspeed(Integer rotatingspeed) {
    this.rotatingspeed = rotatingspeed;
  }
  public motor_data with_rotatingspeed(Integer rotatingspeed) {
    this.rotatingspeed = rotatingspeed;
    return this;
  }
  private Integer temperature;
  public Integer get_temperature() {
    return temperature;
  }
  public void set_temperature(Integer temperature) {
    this.temperature = temperature;
  }
  public motor_data with_temperature(Integer temperature) {
    this.temperature = temperature;
    return this;
  }
  private Double controllercurrent;
  public Double get_controllercurrent() {
    return controllercurrent;
  }
  public void set_controllercurrent(Double controllercurrent) {
    this.controllercurrent = controllercurrent;
  }
  public motor_data with_controllercurrent(Double controllercurrent) {
    this.controllercurrent = controllercurrent;
    return this;
  }
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof motor_data)) {
      return false;
    }
    motor_data that = (motor_data) o;
    boolean equal = true;
    equal = equal && (this.orgseq == null ? that.orgseq == null : this.orgseq.equals(that.orgseq));
    equal = equal && (this.vehiclemodelseq == null ? that.vehiclemodelseq == null : this.vehiclemodelseq.equals(that.vehiclemodelseq));
    equal = equal && (this.vehicleseq == null ? that.vehicleseq == null : this.vehicleseq.equals(that.vehicleseq));
    equal = equal && (this.districtseq == null ? that.districtseq == null : this.districtseq.equals(that.districtseq));
    equal = equal && (this.datatime == null ? that.datatime == null : this.datatime.equals(that.datatime));
    equal = equal && (this.ctrollertmp == null ? that.ctrollertmp == null : this.ctrollertmp.equals(that.ctrollertmp));
    equal = equal && (this.rotatingspeed == null ? that.rotatingspeed == null : this.rotatingspeed.equals(that.rotatingspeed));
    equal = equal && (this.temperature == null ? that.temperature == null : this.temperature.equals(that.temperature));
    equal = equal && (this.controllercurrent == null ? that.controllercurrent == null : this.controllercurrent.equals(that.controllercurrent));
    return equal;
  }
  public boolean equals0(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof motor_data)) {
      return false;
    }
    motor_data that = (motor_data) o;
    boolean equal = true;
    equal = equal && (this.orgseq == null ? that.orgseq == null : this.orgseq.equals(that.orgseq));
    equal = equal && (this.vehiclemodelseq == null ? that.vehiclemodelseq == null : this.vehiclemodelseq.equals(that.vehiclemodelseq));
    equal = equal && (this.vehicleseq == null ? that.vehicleseq == null : this.vehicleseq.equals(that.vehicleseq));
    equal = equal && (this.districtseq == null ? that.districtseq == null : this.districtseq.equals(that.districtseq));
    equal = equal && (this.datatime == null ? that.datatime == null : this.datatime.equals(that.datatime));
    equal = equal && (this.ctrollertmp == null ? that.ctrollertmp == null : this.ctrollertmp.equals(that.ctrollertmp));
    equal = equal && (this.rotatingspeed == null ? that.rotatingspeed == null : this.rotatingspeed.equals(that.rotatingspeed));
    equal = equal && (this.temperature == null ? that.temperature == null : this.temperature.equals(that.temperature));
    equal = equal && (this.controllercurrent == null ? that.controllercurrent == null : this.controllercurrent.equals(that.controllercurrent));
    return equal;
  }
  public void readFields(ResultSet __dbResults) throws SQLException {
    this.__cur_result_set = __dbResults;
    this.orgseq = JdbcWritableBridge.readInteger(1, __dbResults);
    this.vehiclemodelseq = JdbcWritableBridge.readInteger(2, __dbResults);
    this.vehicleseq = JdbcWritableBridge.readLong(3, __dbResults);
    this.districtseq = JdbcWritableBridge.readInteger(4, __dbResults);
    this.datatime = JdbcWritableBridge.readTimestamp(5, __dbResults);
    this.ctrollertmp = JdbcWritableBridge.readInteger(6, __dbResults);
    this.rotatingspeed = JdbcWritableBridge.readInteger(7, __dbResults);
    this.temperature = JdbcWritableBridge.readInteger(8, __dbResults);
    this.controllercurrent = JdbcWritableBridge.readDouble(9, __dbResults);
  }
  public void readFields0(ResultSet __dbResults) throws SQLException {
    this.orgseq = JdbcWritableBridge.readInteger(1, __dbResults);
    this.vehiclemodelseq = JdbcWritableBridge.readInteger(2, __dbResults);
    this.vehicleseq = JdbcWritableBridge.readLong(3, __dbResults);
    this.districtseq = JdbcWritableBridge.readInteger(4, __dbResults);
    this.datatime = JdbcWritableBridge.readTimestamp(5, __dbResults);
    this.ctrollertmp = JdbcWritableBridge.readInteger(6, __dbResults);
    this.rotatingspeed = JdbcWritableBridge.readInteger(7, __dbResults);
    this.temperature = JdbcWritableBridge.readInteger(8, __dbResults);
    this.controllercurrent = JdbcWritableBridge.readDouble(9, __dbResults);
  }
  public void loadLargeObjects(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void loadLargeObjects0(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void write(PreparedStatement __dbStmt) throws SQLException {
    write(__dbStmt, 0);
  }

  public int write(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeInteger(orgseq, 1 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(vehiclemodelseq, 2 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeLong(vehicleseq, 3 + __off, -5, __dbStmt);
    JdbcWritableBridge.writeInteger(districtseq, 4 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeTimestamp(datatime, 5 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeInteger(ctrollertmp, 6 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(rotatingspeed, 7 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(temperature, 8 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeDouble(controllercurrent, 9 + __off, 8, __dbStmt);
    return 9;
  }
  public void write0(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeInteger(orgseq, 1 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(vehiclemodelseq, 2 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeLong(vehicleseq, 3 + __off, -5, __dbStmt);
    JdbcWritableBridge.writeInteger(districtseq, 4 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeTimestamp(datatime, 5 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeInteger(ctrollertmp, 6 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(rotatingspeed, 7 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(temperature, 8 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeDouble(controllercurrent, 9 + __off, 8, __dbStmt);
  }
  public void readFields(DataInput __dataIn) throws IOException {
this.readFields0(__dataIn);  }
  public void readFields0(DataInput __dataIn) throws IOException {
    if (__dataIn.readBoolean()) { 
        this.orgseq = null;
    } else {
    this.orgseq = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.vehiclemodelseq = null;
    } else {
    this.vehiclemodelseq = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.vehicleseq = null;
    } else {
    this.vehicleseq = Long.valueOf(__dataIn.readLong());
    }
    if (__dataIn.readBoolean()) { 
        this.districtseq = null;
    } else {
    this.districtseq = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.datatime = null;
    } else {
    this.datatime = new Timestamp(__dataIn.readLong());
    this.datatime.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.ctrollertmp = null;
    } else {
    this.ctrollertmp = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.rotatingspeed = null;
    } else {
    this.rotatingspeed = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.temperature = null;
    } else {
    this.temperature = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.controllercurrent = null;
    } else {
    this.controllercurrent = Double.valueOf(__dataIn.readDouble());
    }
  }
  public void write(DataOutput __dataOut) throws IOException {
    if (null == this.orgseq) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.orgseq);
    }
    if (null == this.vehiclemodelseq) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.vehiclemodelseq);
    }
    if (null == this.vehicleseq) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.vehicleseq);
    }
    if (null == this.districtseq) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.districtseq);
    }
    if (null == this.datatime) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.datatime.getTime());
    __dataOut.writeInt(this.datatime.getNanos());
    }
    if (null == this.ctrollertmp) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.ctrollertmp);
    }
    if (null == this.rotatingspeed) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.rotatingspeed);
    }
    if (null == this.temperature) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.temperature);
    }
    if (null == this.controllercurrent) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeDouble(this.controllercurrent);
    }
  }
  public void write0(DataOutput __dataOut) throws IOException {
    if (null == this.orgseq) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.orgseq);
    }
    if (null == this.vehiclemodelseq) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.vehiclemodelseq);
    }
    if (null == this.vehicleseq) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.vehicleseq);
    }
    if (null == this.districtseq) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.districtseq);
    }
    if (null == this.datatime) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.datatime.getTime());
    __dataOut.writeInt(this.datatime.getNanos());
    }
    if (null == this.ctrollertmp) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.ctrollertmp);
    }
    if (null == this.rotatingspeed) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.rotatingspeed);
    }
    if (null == this.temperature) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.temperature);
    }
    if (null == this.controllercurrent) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeDouble(this.controllercurrent);
    }
  }
  private static final DelimiterSet __outputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  public String toString() {
    return toString(__outputDelimiters, true);
  }
  public String toString(DelimiterSet delimiters) {
    return toString(delimiters, true);
  }
  public String toString(boolean useRecordDelim) {
    return toString(__outputDelimiters, useRecordDelim);
  }
  public String toString(DelimiterSet delimiters, boolean useRecordDelim) {
    StringBuilder __sb = new StringBuilder();
    char fieldDelim = delimiters.getFieldsTerminatedBy();
    __sb.append(FieldFormatter.escapeAndEnclose(orgseq==null?"null":"" + orgseq, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(vehiclemodelseq==null?"null":"" + vehiclemodelseq, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(vehicleseq==null?"null":"" + vehicleseq, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(districtseq==null?"null":"" + districtseq, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(datatime==null?"null":"" + datatime, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ctrollertmp==null?"null":"" + ctrollertmp, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(rotatingspeed==null?"null":"" + rotatingspeed, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(temperature==null?"null":"" + temperature, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(controllercurrent==null?"null":"" + controllercurrent, delimiters));
    if (useRecordDelim) {
      __sb.append(delimiters.getLinesTerminatedBy());
    }
    return __sb.toString();
  }
  public void toString0(DelimiterSet delimiters, StringBuilder __sb, char fieldDelim) {
    __sb.append(FieldFormatter.escapeAndEnclose(orgseq==null?"null":"" + orgseq, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(vehiclemodelseq==null?"null":"" + vehiclemodelseq, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(vehicleseq==null?"null":"" + vehicleseq, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(districtseq==null?"null":"" + districtseq, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(datatime==null?"null":"" + datatime, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(ctrollertmp==null?"null":"" + ctrollertmp, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(rotatingspeed==null?"null":"" + rotatingspeed, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(temperature==null?"null":"" + temperature, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(controllercurrent==null?"null":"" + controllercurrent, delimiters));
  }
  private static final DelimiterSet __inputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  private RecordParser __parser;
  public void parse(Text __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharSequence __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(byte [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(char [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(ByteBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  private void __loadFromFields(List<String> fields) {
    Iterator<String> __it = fields.listIterator();
    String __cur_str = null;
    try {
    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.orgseq = null; } else {
      this.orgseq = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.vehiclemodelseq = null; } else {
      this.vehiclemodelseq = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.vehicleseq = null; } else {
      this.vehicleseq = Long.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.districtseq = null; } else {
      this.districtseq = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.datatime = null; } else {
      this.datatime = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.ctrollertmp = null; } else {
      this.ctrollertmp = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.rotatingspeed = null; } else {
      this.rotatingspeed = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.temperature = null; } else {
      this.temperature = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.controllercurrent = null; } else {
      this.controllercurrent = Double.valueOf(__cur_str);
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  private void __loadFromFields0(Iterator<String> __it) {
    String __cur_str = null;
    try {
    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.orgseq = null; } else {
      this.orgseq = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.vehiclemodelseq = null; } else {
      this.vehiclemodelseq = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.vehicleseq = null; } else {
      this.vehicleseq = Long.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.districtseq = null; } else {
      this.districtseq = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.datatime = null; } else {
      this.datatime = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.ctrollertmp = null; } else {
      this.ctrollertmp = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.rotatingspeed = null; } else {
      this.rotatingspeed = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.temperature = null; } else {
      this.temperature = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.controllercurrent = null; } else {
      this.controllercurrent = Double.valueOf(__cur_str);
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  public Object clone() throws CloneNotSupportedException {
    motor_data o = (motor_data) super.clone();
    o.datatime = (o.datatime != null) ? (java.sql.Timestamp) o.datatime.clone() : null;
    return o;
  }

  public void clone0(motor_data o) throws CloneNotSupportedException {
    o.datatime = (o.datatime != null) ? (java.sql.Timestamp) o.datatime.clone() : null;
  }

  public Map<String, Object> getFieldMap() {
    Map<String, Object> __sqoop$field_map = new TreeMap<String, Object>();
    __sqoop$field_map.put("orgseq", this.orgseq);
    __sqoop$field_map.put("vehiclemodelseq", this.vehiclemodelseq);
    __sqoop$field_map.put("vehicleseq", this.vehicleseq);
    __sqoop$field_map.put("districtseq", this.districtseq);
    __sqoop$field_map.put("datatime", this.datatime);
    __sqoop$field_map.put("ctrollertmp", this.ctrollertmp);
    __sqoop$field_map.put("rotatingspeed", this.rotatingspeed);
    __sqoop$field_map.put("temperature", this.temperature);
    __sqoop$field_map.put("controllercurrent", this.controllercurrent);
    return __sqoop$field_map;
  }

  public void getFieldMap0(Map<String, Object> __sqoop$field_map) {
    __sqoop$field_map.put("orgseq", this.orgseq);
    __sqoop$field_map.put("vehiclemodelseq", this.vehiclemodelseq);
    __sqoop$field_map.put("vehicleseq", this.vehicleseq);
    __sqoop$field_map.put("districtseq", this.districtseq);
    __sqoop$field_map.put("datatime", this.datatime);
    __sqoop$field_map.put("ctrollertmp", this.ctrollertmp);
    __sqoop$field_map.put("rotatingspeed", this.rotatingspeed);
    __sqoop$field_map.put("temperature", this.temperature);
    __sqoop$field_map.put("controllercurrent", this.controllercurrent);
  }

  public void setField(String __fieldName, Object __fieldVal) {
    if ("orgseq".equals(__fieldName)) {
      this.orgseq = (Integer) __fieldVal;
    }
    else    if ("vehiclemodelseq".equals(__fieldName)) {
      this.vehiclemodelseq = (Integer) __fieldVal;
    }
    else    if ("vehicleseq".equals(__fieldName)) {
      this.vehicleseq = (Long) __fieldVal;
    }
    else    if ("districtseq".equals(__fieldName)) {
      this.districtseq = (Integer) __fieldVal;
    }
    else    if ("datatime".equals(__fieldName)) {
      this.datatime = (java.sql.Timestamp) __fieldVal;
    }
    else    if ("ctrollertmp".equals(__fieldName)) {
      this.ctrollertmp = (Integer) __fieldVal;
    }
    else    if ("rotatingspeed".equals(__fieldName)) {
      this.rotatingspeed = (Integer) __fieldVal;
    }
    else    if ("temperature".equals(__fieldName)) {
      this.temperature = (Integer) __fieldVal;
    }
    else    if ("controllercurrent".equals(__fieldName)) {
      this.controllercurrent = (Double) __fieldVal;
    }
    else {
      throw new RuntimeException("No such field: " + __fieldName);
    }
  }
  public boolean setField0(String __fieldName, Object __fieldVal) {
    if ("orgseq".equals(__fieldName)) {
      this.orgseq = (Integer) __fieldVal;
      return true;
    }
    else    if ("vehiclemodelseq".equals(__fieldName)) {
      this.vehiclemodelseq = (Integer) __fieldVal;
      return true;
    }
    else    if ("vehicleseq".equals(__fieldName)) {
      this.vehicleseq = (Long) __fieldVal;
      return true;
    }
    else    if ("districtseq".equals(__fieldName)) {
      this.districtseq = (Integer) __fieldVal;
      return true;
    }
    else    if ("datatime".equals(__fieldName)) {
      this.datatime = (java.sql.Timestamp) __fieldVal;
      return true;
    }
    else    if ("ctrollertmp".equals(__fieldName)) {
      this.ctrollertmp = (Integer) __fieldVal;
      return true;
    }
    else    if ("rotatingspeed".equals(__fieldName)) {
      this.rotatingspeed = (Integer) __fieldVal;
      return true;
    }
    else    if ("temperature".equals(__fieldName)) {
      this.temperature = (Integer) __fieldVal;
      return true;
    }
    else    if ("controllercurrent".equals(__fieldName)) {
      this.controllercurrent = (Double) __fieldVal;
      return true;
    }
    else {
      return false;    }
  }
}
