#! /bin/bash
echo "====================== begin battery mr ! ======================="
hadoop jar /root/app/evcard.jar com.extrame.data.process.hbase.mr.BatteryMr
echo "======================  end battery mr !  ======================="



echo "====================== begin alarm mr ! ======================="
hadoop jar /root/app/evcard.jar com.extrame.data.process.hbase.mr.AlarmMr
echo "======================  end alarm mr !  ======================="



echo "====================== begin insert overwrite ! ======================="
hive -f /root/app/hivesqls.txt
echo "====================== end insert overwrite ! ======================="


echo "====================== begin sqoop export ! ======================="

## alarm_data
echo "====================== begin export alarm_data ! ======================="
 sqoop export \
  -D mapreduce.map.memory.mb=2048 \
  -D yarn.app.mapreduce.am.resource.mb=2048 \
  --connect jdbc:mysql://172.16.10.11:3092/guobiao\
  --username histore\
  --password _histore_cpp\
  --table alarm_data \
  --m 2\
  --export-dir /user/hive/warehouse/alarm_data_hive/ \
  --fields-terminated-by '\001' \
  --lines-terminated-by '\n' \
  --columns orgseq,vehiclemodelseq,vehicleseq,districtseq,datatime,maxalarmlevel,comalarmflag \
  --input-null-string '\\N' --input-null-non-string '\\N';
echo "====================== end export alarm_data ! ======================="


## vehicle_position
echo "====================== begin export vehicle_position ! ======================="
 sqoop export \
  -D mapreduce.map.memory.mb=2048 \
  -D yarn.app.mapreduce.am.resource.mb=2048 \
  --connect jdbc:mysql://172.16.10.11:3092/guobiao\
  --username histore\
  --password _histore_cpp\
  --table vehicle_position \
  --m 2\
  --export-dir /user/hive/warehouse/vehicle_position_hive/ \
  --fields-terminated-by '\001' \
  --lines-terminated-by '\n' \
  --columns orgseq,vehiclemodelseq,vehicleseq,districtseq,datatime,latitude,locationstate,longitude \
  --input-null-string '\\N' --input-null-non-string '\\N';
echo "====================== end export vehicle_position ! ======================="

## vehicle_data
echo "====================== begin export vehicle_data ! ======================="
 sqoop export \
  -D mapreduce.map.memory.mb=2048 \
  -D yarn.app.mapreduce.am.resource.mb=2048 \
  --connect jdbc:mysql://172.16.10.11:3092/guobiao\
  --username histore\
  --password _histore_cpp\
  --table vehicle_data \
  --m 2\
  --export-dir /user/hive/warehouse/vehicle_data_hive/ \
  --fields-terminated-by '\001' \
  --lines-terminated-by '\n' \
  --columns orgseq,vehiclemodelseq,vehicleseq,districtseq,datatime,summileage,speed,vehiclestatus,soc,insulationresistance \
  --input-null-string '\\N' --input-null-non-string '\\N';
echo "====================== end export vehicle_data ! ======================="

## motor_data
echo "====================== begin export motor_data ! ======================="
 sqoop export \
  -D mapreduce.map.memory.mb=2048 \
  -D yarn.app.mapreduce.am.resource.mb=2048 \
  --connect jdbc:mysql://172.16.10.11:3092/guobiao\
  --username histore\
  --password _histore_cpp\
  --table motor_data \
  --m 2\
  --export-dir /user/hive/warehouse/motor_data_hive/ \
  --fields-terminated-by '\001' \
  --lines-terminated-by '\n' \
  --columns orgseq,vehiclemodelseq,vehicleseq,districtseq,datatime,ctrollertmp,rotatingspeed,temperature,controllercurrent \
  --input-null-string '\\N' --input-null-non-string '\\N';
echo "====================== end export motor_data ! ======================="

 ## engine_data
echo "====================== begin export engine_data ! ======================="
 sqoop export \
  -D mapreduce.map.memory.mb=2048 \
  -D yarn.app.mapreduce.am.resource.mb=2048 \
  --connect jdbc:mysql://172.16.10.11:3092/guobiao\
  --username histore\
  --password _histore_cpp\
  --table engine_data \
  --m 2\
  --export-dir /user/hive/warehouse/engine_data_hive/ \
  --fields-terminated-by '\001' \
  --lines-terminated-by '\n' \
  --columns orgseq,vehiclemodelseq,vehicleseq,districtseq,datatime,enginefuelconsumptionrate \
  --input-null-string '\\N' --input-null-non-string '\\N';
echo "====================== end export engine_data ! ======================="

## extreme_value
echo "====================== begin export extreme_value ! ======================="
sqoop export \
 -D mapreduce.map.memory.mb=2048 \
 -D yarn.app.mapreduce.am.resource.mb=2048 \
 --connect jdbc:mysql://172.16.10.11:3092/guobiao\
 --username histore\
 --password _histore_cpp\
 --table extreme_value \
 --m 2\
 --export-dir /user/hive/warehouse/extreme_value_hive/ \
 --fields-terminated-by '\001' \
 --lines-terminated-by '\n' \
 --columns orgseq,vehiclemodelseq,vehicleseq,districtseq,datatime,maxtmpval,mintmpval,maxbatterysinglevoltageval,minbatterysinglevoltageval \
 --input-null-string '\\N' --input-null-non-string '\\N';
echo "====================== end export extreme_value ! ======================="

## dibiao_add_data
echo "====================== begin export dibiao_add_data ! ======================="
sqoop export \
 -D mapreduce.map.memory.mb=2048 \
 -D yarn.app.mapreduce.am.resource.mb=2048 \
 --connect jdbc:mysql://172.16.10.11:3092/guobiao\
 --username histore\
 --password _histore_cpp\
 --table dibiao_add_data \
 --m 2\
 --export-dir /user/hive/warehouse/dibiao_add_data_hive/ \
 --fields-terminated-by '\001' \
 --lines-terminated-by '\n' \
 --columns orgseq,vehiclemodelseq,vehicleseq,districtseq,datatime,startfiretime,endfiretime,direction,acceleratorpedal,brakestatus,powersystemready,emergencypowerdown,highvoltagecurrent,remainingbattery,batterypowersum,balanceactivated,tmppakage,tmppakagelist \
 --input-null-string '\\N' --input-null-non-string '\\N';
echo "====================== end export dibiao_add_data ! ======================="

echo "====================== end sqoop export ! ======================="
