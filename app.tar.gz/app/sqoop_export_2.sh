#! /bin/bash
echo "====================== begin export alarm_data ! ======================="
 sqoop export \
  -D mapreduce.map.memory.mb=2048 \
  -D yarn.app.mapreduce.am.resource.mb=2048 \
  --connect jdbc:mysql://172.16.10.11:3092/guobiao\
  --username histore\
  --password _histore_cpp\
  --table alarm_data \
  --m 1\
  --export-dir /user/hive/warehouse/alarm_data_hive/ \
  --fields-terminated-by '\001' \
  --lines-terminated-by '\n' \
  --columns orgseq,vehiclemodelseq,vehicleseq,districtseq,datatime,maxalarmlevel,comalarmflag \
  --input-null-string '\\N' --input-null-non-string '\\N';
echo "====================== end export alarm_data ! ======================="

echo "====================== begin export dibiao_add_data ! ======================="
sqoop export \
 -D mapreduce.map.memory.mb=2048 \
 -D yarn.app.mapreduce.am.resource.mb=2048 \
 --connect jdbc:mysql://172.16.10.11:3092/guobiao\
 --username histore\
 --password _histore_cpp\
 --table dibiao_add_data \
 --m 1\
 --export-dir /user/hive/warehouse/dibiao_add_data_hive/ \
 --fields-terminated-by '\001' \
 --lines-terminated-by '\n' \
 --columns orgseq,vehiclemodelseq,vehicleseq,districtseq,datatime,startfiretime,endfiretime,direction,acceleratorpedal,brakestatus,powersystemready,emergencypowerdown,highvoltagecurrent,remainingbattery,batterypowersum,balanceactivated,tmppakage,tmppakagelist \
 --input-null-string '\\N' --input-null-non-string '\\N';
echo "====================== end export dibiao_add_data ! ======================="
