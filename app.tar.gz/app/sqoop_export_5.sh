#! /bin/bash

## vehicle_position
echo "====================== begin export vehicle_position ! ======================="
 sqoop export \
  -D mapreduce.map.memory.mb=2048 \
  -D yarn.app.mapreduce.am.resource.mb=2048 \
  --connect jdbc:mysql://172.16.10.11:3092/guobiao\
  --username histore\
  --password _histore_cpp\
  --table vehicle_position \
  --m 1\
  --export-dir /user/hive/warehouse/vehicle_position_hive/ \
  --fields-terminated-by '\001' \
  --lines-terminated-by '\n' \
  --columns orgseq,vehiclemodelseq,vehicleseq,districtseq,datatime,latitude,locationstate,longitude \
  --input-null-string '\\N' --input-null-non-string '\\N';
echo "====================== end export vehicle_position ! ======================="

## vehicle_data
echo "====================== begin export vehicle_data ! ======================="
 sqoop export \
  -D mapreduce.map.memory.mb=2048 \
  -D yarn.app.mapreduce.am.resource.mb=2048 \
  --connect jdbc:mysql://172.16.10.11:3092/guobiao\
  --username histore\
  --password _histore_cpp\
  --table vehicle_data \
  --m 1\
  --export-dir /user/hive/warehouse/vehicle_data_hive/ \
  --fields-terminated-by '\001' \
  --lines-terminated-by '\n' \
  --columns orgseq,vehiclemodelseq,vehicleseq,districtseq,datatime,summileage,speed,vehiclestatus,soc,insulationresistance \
  --input-null-string '\\N' --input-null-non-string '\\N';
echo "====================== end export vehicle_data ! ======================="

## motor_data
echo "====================== begin export motor_data ! ======================="
 sqoop export \
  -D mapreduce.map.memory.mb=2048 \
  -D yarn.app.mapreduce.am.resource.mb=2048 \
  --connect jdbc:mysql://172.16.10.11:3092/guobiao\
  --username histore\
  --password _histore_cpp\
  --table motor_data \
  --m 1\
  --export-dir /user/hive/warehouse/motor_data_hive/ \
  --fields-terminated-by '\001' \
  --lines-terminated-by '\n' \
  --columns orgseq,vehiclemodelseq,vehicleseq,districtseq,datatime,ctrollertmp,rotatingspeed,temperature,controllercurrent \
  --input-null-string '\\N' --input-null-non-string '\\N';
echo "====================== end export motor_data ! ======================="

 ## engine_data
echo "====================== begin export engine_data ! ======================="
 sqoop export \
  -D mapreduce.map.memory.mb=2048 \
  -D yarn.app.mapreduce.am.resource.mb=2048 \
  --connect jdbc:mysql://172.16.10.11:3092/guobiao\
  --username histore\
  --password _histore_cpp\
  --table engine_data \
  --m 1\
  --export-dir /user/hive/warehouse/engine_data_hive/ \
  --fields-terminated-by '\001' \
  --lines-terminated-by '\n' \
  --columns orgseq,vehiclemodelseq,vehicleseq,districtseq,datatime,enginefuelconsumptionrate \
  --input-null-string '\\N' --input-null-non-string '\\N';
echo "====================== end export engine_data ! ======================="

## extreme_value
echo "====================== begin export extreme_value ! ======================="
sqoop export \
 -D mapreduce.map.memory.mb=2048 \
 -D yarn.app.mapreduce.am.resource.mb=2048 \
 --connect jdbc:mysql://172.16.10.11:3092/guobiao\
 --username histore\
 --password _histore_cpp\
 --table extreme_value \
 --m 1\
 --export-dir /user/hive/warehouse/extreme_value_hive/ \
 --fields-terminated-by '\001' \
 --lines-terminated-by '\n' \
 --columns orgseq,vehiclemodelseq,vehicleseq,districtseq,datatime,maxtmpval,mintmpval,maxbatterysinglevoltageval,minbatterysinglevoltageval \
 --input-null-string '\\N' --input-null-non-string '\\N';
echo "====================== end export extreme_value ! ======================="
