#! /bin/bash

echo "11";

echo "22";

eco "1"

echo "33";
