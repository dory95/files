#!/bin/bash

exec $HBASE_HOME/bin/hbase shell <<EOF
truncate 'dibiao_add_data_1'
truncate 'engine_data_1'
truncate 'extreme_value_1'
truncate 'motor_data_1'
truncate 'temp_alarm_1'
truncate 'temp_tembatterypack_1'
truncate 'vehicle_data_1'
truncate 'vehicle_position_1'
truncate 'alarm_data_1'
EOF
