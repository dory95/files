// ORM class for table 'extreme_value'
// WARNING: This class is AUTO-GENERATED. Modify at your own risk.
//
// Debug information:
// Generated date: Sun Jan 28 10:59:58 CST 2018
// For connector: org.apache.sqoop.manager.MySQLManager
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapred.lib.db.DBWritable;
import com.cloudera.sqoop.lib.JdbcWritableBridge;
import com.cloudera.sqoop.lib.DelimiterSet;
import com.cloudera.sqoop.lib.FieldFormatter;
import com.cloudera.sqoop.lib.RecordParser;
import com.cloudera.sqoop.lib.BooleanParser;
import com.cloudera.sqoop.lib.BlobRef;
import com.cloudera.sqoop.lib.ClobRef;
import com.cloudera.sqoop.lib.LargeObjectLoader;
import com.cloudera.sqoop.lib.SqoopRecord;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class extreme_value extends SqoopRecord  implements DBWritable, Writable {
  private final int PROTOCOL_VERSION = 3;
  public int getClassFormatVersion() { return PROTOCOL_VERSION; }
  protected ResultSet __cur_result_set;
  private Integer orgseq;
  public Integer get_orgseq() {
    return orgseq;
  }
  public void set_orgseq(Integer orgseq) {
    this.orgseq = orgseq;
  }
  public extreme_value with_orgseq(Integer orgseq) {
    this.orgseq = orgseq;
    return this;
  }
  private Integer vehiclemodelseq;
  public Integer get_vehiclemodelseq() {
    return vehiclemodelseq;
  }
  public void set_vehiclemodelseq(Integer vehiclemodelseq) {
    this.vehiclemodelseq = vehiclemodelseq;
  }
  public extreme_value with_vehiclemodelseq(Integer vehiclemodelseq) {
    this.vehiclemodelseq = vehiclemodelseq;
    return this;
  }
  private Long vehicleseq;
  public Long get_vehicleseq() {
    return vehicleseq;
  }
  public void set_vehicleseq(Long vehicleseq) {
    this.vehicleseq = vehicleseq;
  }
  public extreme_value with_vehicleseq(Long vehicleseq) {
    this.vehicleseq = vehicleseq;
    return this;
  }
  private Integer districtseq;
  public Integer get_districtseq() {
    return districtseq;
  }
  public void set_districtseq(Integer districtseq) {
    this.districtseq = districtseq;
  }
  public extreme_value with_districtseq(Integer districtseq) {
    this.districtseq = districtseq;
    return this;
  }
  private java.sql.Timestamp datatime;
  public java.sql.Timestamp get_datatime() {
    return datatime;
  }
  public void set_datatime(java.sql.Timestamp datatime) {
    this.datatime = datatime;
  }
  public extreme_value with_datatime(java.sql.Timestamp datatime) {
    this.datatime = datatime;
    return this;
  }
  private Integer maxtmpval;
  public Integer get_maxtmpval() {
    return maxtmpval;
  }
  public void set_maxtmpval(Integer maxtmpval) {
    this.maxtmpval = maxtmpval;
  }
  public extreme_value with_maxtmpval(Integer maxtmpval) {
    this.maxtmpval = maxtmpval;
    return this;
  }
  private Integer mintmpval;
  public Integer get_mintmpval() {
    return mintmpval;
  }
  public void set_mintmpval(Integer mintmpval) {
    this.mintmpval = mintmpval;
  }
  public extreme_value with_mintmpval(Integer mintmpval) {
    this.mintmpval = mintmpval;
    return this;
  }
  private Double maxbatterysinglevoltageval;
  public Double get_maxbatterysinglevoltageval() {
    return maxbatterysinglevoltageval;
  }
  public void set_maxbatterysinglevoltageval(Double maxbatterysinglevoltageval) {
    this.maxbatterysinglevoltageval = maxbatterysinglevoltageval;
  }
  public extreme_value with_maxbatterysinglevoltageval(Double maxbatterysinglevoltageval) {
    this.maxbatterysinglevoltageval = maxbatterysinglevoltageval;
    return this;
  }
  private Double minbatterysinglevoltageval;
  public Double get_minbatterysinglevoltageval() {
    return minbatterysinglevoltageval;
  }
  public void set_minbatterysinglevoltageval(Double minbatterysinglevoltageval) {
    this.minbatterysinglevoltageval = minbatterysinglevoltageval;
  }
  public extreme_value with_minbatterysinglevoltageval(Double minbatterysinglevoltageval) {
    this.minbatterysinglevoltageval = minbatterysinglevoltageval;
    return this;
  }
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof extreme_value)) {
      return false;
    }
    extreme_value that = (extreme_value) o;
    boolean equal = true;
    equal = equal && (this.orgseq == null ? that.orgseq == null : this.orgseq.equals(that.orgseq));
    equal = equal && (this.vehiclemodelseq == null ? that.vehiclemodelseq == null : this.vehiclemodelseq.equals(that.vehiclemodelseq));
    equal = equal && (this.vehicleseq == null ? that.vehicleseq == null : this.vehicleseq.equals(that.vehicleseq));
    equal = equal && (this.districtseq == null ? that.districtseq == null : this.districtseq.equals(that.districtseq));
    equal = equal && (this.datatime == null ? that.datatime == null : this.datatime.equals(that.datatime));
    equal = equal && (this.maxtmpval == null ? that.maxtmpval == null : this.maxtmpval.equals(that.maxtmpval));
    equal = equal && (this.mintmpval == null ? that.mintmpval == null : this.mintmpval.equals(that.mintmpval));
    equal = equal && (this.maxbatterysinglevoltageval == null ? that.maxbatterysinglevoltageval == null : this.maxbatterysinglevoltageval.equals(that.maxbatterysinglevoltageval));
    equal = equal && (this.minbatterysinglevoltageval == null ? that.minbatterysinglevoltageval == null : this.minbatterysinglevoltageval.equals(that.minbatterysinglevoltageval));
    return equal;
  }
  public boolean equals0(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof extreme_value)) {
      return false;
    }
    extreme_value that = (extreme_value) o;
    boolean equal = true;
    equal = equal && (this.orgseq == null ? that.orgseq == null : this.orgseq.equals(that.orgseq));
    equal = equal && (this.vehiclemodelseq == null ? that.vehiclemodelseq == null : this.vehiclemodelseq.equals(that.vehiclemodelseq));
    equal = equal && (this.vehicleseq == null ? that.vehicleseq == null : this.vehicleseq.equals(that.vehicleseq));
    equal = equal && (this.districtseq == null ? that.districtseq == null : this.districtseq.equals(that.districtseq));
    equal = equal && (this.datatime == null ? that.datatime == null : this.datatime.equals(that.datatime));
    equal = equal && (this.maxtmpval == null ? that.maxtmpval == null : this.maxtmpval.equals(that.maxtmpval));
    equal = equal && (this.mintmpval == null ? that.mintmpval == null : this.mintmpval.equals(that.mintmpval));
    equal = equal && (this.maxbatterysinglevoltageval == null ? that.maxbatterysinglevoltageval == null : this.maxbatterysinglevoltageval.equals(that.maxbatterysinglevoltageval));
    equal = equal && (this.minbatterysinglevoltageval == null ? that.minbatterysinglevoltageval == null : this.minbatterysinglevoltageval.equals(that.minbatterysinglevoltageval));
    return equal;
  }
  public void readFields(ResultSet __dbResults) throws SQLException {
    this.__cur_result_set = __dbResults;
    this.orgseq = JdbcWritableBridge.readInteger(1, __dbResults);
    this.vehiclemodelseq = JdbcWritableBridge.readInteger(2, __dbResults);
    this.vehicleseq = JdbcWritableBridge.readLong(3, __dbResults);
    this.districtseq = JdbcWritableBridge.readInteger(4, __dbResults);
    this.datatime = JdbcWritableBridge.readTimestamp(5, __dbResults);
    this.maxtmpval = JdbcWritableBridge.readInteger(6, __dbResults);
    this.mintmpval = JdbcWritableBridge.readInteger(7, __dbResults);
    this.maxbatterysinglevoltageval = JdbcWritableBridge.readDouble(8, __dbResults);
    this.minbatterysinglevoltageval = JdbcWritableBridge.readDouble(9, __dbResults);
  }
  public void readFields0(ResultSet __dbResults) throws SQLException {
    this.orgseq = JdbcWritableBridge.readInteger(1, __dbResults);
    this.vehiclemodelseq = JdbcWritableBridge.readInteger(2, __dbResults);
    this.vehicleseq = JdbcWritableBridge.readLong(3, __dbResults);
    this.districtseq = JdbcWritableBridge.readInteger(4, __dbResults);
    this.datatime = JdbcWritableBridge.readTimestamp(5, __dbResults);
    this.maxtmpval = JdbcWritableBridge.readInteger(6, __dbResults);
    this.mintmpval = JdbcWritableBridge.readInteger(7, __dbResults);
    this.maxbatterysinglevoltageval = JdbcWritableBridge.readDouble(8, __dbResults);
    this.minbatterysinglevoltageval = JdbcWritableBridge.readDouble(9, __dbResults);
  }
  public void loadLargeObjects(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void loadLargeObjects0(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void write(PreparedStatement __dbStmt) throws SQLException {
    write(__dbStmt, 0);
  }

  public int write(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeInteger(orgseq, 1 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(vehiclemodelseq, 2 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeLong(vehicleseq, 3 + __off, -5, __dbStmt);
    JdbcWritableBridge.writeInteger(districtseq, 4 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeTimestamp(datatime, 5 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeInteger(maxtmpval, 6 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(mintmpval, 7 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeDouble(maxbatterysinglevoltageval, 8 + __off, 8, __dbStmt);
    JdbcWritableBridge.writeDouble(minbatterysinglevoltageval, 9 + __off, 8, __dbStmt);
    return 9;
  }
  public void write0(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeInteger(orgseq, 1 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(vehiclemodelseq, 2 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeLong(vehicleseq, 3 + __off, -5, __dbStmt);
    JdbcWritableBridge.writeInteger(districtseq, 4 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeTimestamp(datatime, 5 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeInteger(maxtmpval, 6 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(mintmpval, 7 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeDouble(maxbatterysinglevoltageval, 8 + __off, 8, __dbStmt);
    JdbcWritableBridge.writeDouble(minbatterysinglevoltageval, 9 + __off, 8, __dbStmt);
  }
  public void readFields(DataInput __dataIn) throws IOException {
this.readFields0(__dataIn);  }
  public void readFields0(DataInput __dataIn) throws IOException {
    if (__dataIn.readBoolean()) { 
        this.orgseq = null;
    } else {
    this.orgseq = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.vehiclemodelseq = null;
    } else {
    this.vehiclemodelseq = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.vehicleseq = null;
    } else {
    this.vehicleseq = Long.valueOf(__dataIn.readLong());
    }
    if (__dataIn.readBoolean()) { 
        this.districtseq = null;
    } else {
    this.districtseq = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.datatime = null;
    } else {
    this.datatime = new Timestamp(__dataIn.readLong());
    this.datatime.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.maxtmpval = null;
    } else {
    this.maxtmpval = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.mintmpval = null;
    } else {
    this.mintmpval = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.maxbatterysinglevoltageval = null;
    } else {
    this.maxbatterysinglevoltageval = Double.valueOf(__dataIn.readDouble());
    }
    if (__dataIn.readBoolean()) { 
        this.minbatterysinglevoltageval = null;
    } else {
    this.minbatterysinglevoltageval = Double.valueOf(__dataIn.readDouble());
    }
  }
  public void write(DataOutput __dataOut) throws IOException {
    if (null == this.orgseq) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.orgseq);
    }
    if (null == this.vehiclemodelseq) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.vehiclemodelseq);
    }
    if (null == this.vehicleseq) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.vehicleseq);
    }
    if (null == this.districtseq) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.districtseq);
    }
    if (null == this.datatime) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.datatime.getTime());
    __dataOut.writeInt(this.datatime.getNanos());
    }
    if (null == this.maxtmpval) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.maxtmpval);
    }
    if (null == this.mintmpval) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.mintmpval);
    }
    if (null == this.maxbatterysinglevoltageval) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeDouble(this.maxbatterysinglevoltageval);
    }
    if (null == this.minbatterysinglevoltageval) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeDouble(this.minbatterysinglevoltageval);
    }
  }
  public void write0(DataOutput __dataOut) throws IOException {
    if (null == this.orgseq) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.orgseq);
    }
    if (null == this.vehiclemodelseq) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.vehiclemodelseq);
    }
    if (null == this.vehicleseq) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.vehicleseq);
    }
    if (null == this.districtseq) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.districtseq);
    }
    if (null == this.datatime) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.datatime.getTime());
    __dataOut.writeInt(this.datatime.getNanos());
    }
    if (null == this.maxtmpval) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.maxtmpval);
    }
    if (null == this.mintmpval) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.mintmpval);
    }
    if (null == this.maxbatterysinglevoltageval) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeDouble(this.maxbatterysinglevoltageval);
    }
    if (null == this.minbatterysinglevoltageval) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeDouble(this.minbatterysinglevoltageval);
    }
  }
  private static final DelimiterSet __outputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  public String toString() {
    return toString(__outputDelimiters, true);
  }
  public String toString(DelimiterSet delimiters) {
    return toString(delimiters, true);
  }
  public String toString(boolean useRecordDelim) {
    return toString(__outputDelimiters, useRecordDelim);
  }
  public String toString(DelimiterSet delimiters, boolean useRecordDelim) {
    StringBuilder __sb = new StringBuilder();
    char fieldDelim = delimiters.getFieldsTerminatedBy();
    __sb.append(FieldFormatter.escapeAndEnclose(orgseq==null?"null":"" + orgseq, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(vehiclemodelseq==null?"null":"" + vehiclemodelseq, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(vehicleseq==null?"null":"" + vehicleseq, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(districtseq==null?"null":"" + districtseq, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(datatime==null?"null":"" + datatime, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(maxtmpval==null?"null":"" + maxtmpval, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(mintmpval==null?"null":"" + mintmpval, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(maxbatterysinglevoltageval==null?"null":"" + maxbatterysinglevoltageval, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(minbatterysinglevoltageval==null?"null":"" + minbatterysinglevoltageval, delimiters));
    if (useRecordDelim) {
      __sb.append(delimiters.getLinesTerminatedBy());
    }
    return __sb.toString();
  }
  public void toString0(DelimiterSet delimiters, StringBuilder __sb, char fieldDelim) {
    __sb.append(FieldFormatter.escapeAndEnclose(orgseq==null?"null":"" + orgseq, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(vehiclemodelseq==null?"null":"" + vehiclemodelseq, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(vehicleseq==null?"null":"" + vehicleseq, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(districtseq==null?"null":"" + districtseq, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(datatime==null?"null":"" + datatime, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(maxtmpval==null?"null":"" + maxtmpval, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(mintmpval==null?"null":"" + mintmpval, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(maxbatterysinglevoltageval==null?"null":"" + maxbatterysinglevoltageval, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(minbatterysinglevoltageval==null?"null":"" + minbatterysinglevoltageval, delimiters));
  }
  private static final DelimiterSet __inputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  private RecordParser __parser;
  public void parse(Text __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharSequence __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(byte [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(char [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(ByteBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  private void __loadFromFields(List<String> fields) {
    Iterator<String> __it = fields.listIterator();
    String __cur_str = null;
    try {
    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.orgseq = null; } else {
      this.orgseq = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.vehiclemodelseq = null; } else {
      this.vehiclemodelseq = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.vehicleseq = null; } else {
      this.vehicleseq = Long.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.districtseq = null; } else {
      this.districtseq = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.datatime = null; } else {
      this.datatime = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.maxtmpval = null; } else {
      this.maxtmpval = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.mintmpval = null; } else {
      this.mintmpval = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.maxbatterysinglevoltageval = null; } else {
      this.maxbatterysinglevoltageval = Double.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.minbatterysinglevoltageval = null; } else {
      this.minbatterysinglevoltageval = Double.valueOf(__cur_str);
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  private void __loadFromFields0(Iterator<String> __it) {
    String __cur_str = null;
    try {
    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.orgseq = null; } else {
      this.orgseq = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.vehiclemodelseq = null; } else {
      this.vehiclemodelseq = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.vehicleseq = null; } else {
      this.vehicleseq = Long.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.districtseq = null; } else {
      this.districtseq = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.datatime = null; } else {
      this.datatime = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.maxtmpval = null; } else {
      this.maxtmpval = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.mintmpval = null; } else {
      this.mintmpval = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.maxbatterysinglevoltageval = null; } else {
      this.maxbatterysinglevoltageval = Double.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.minbatterysinglevoltageval = null; } else {
      this.minbatterysinglevoltageval = Double.valueOf(__cur_str);
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  public Object clone() throws CloneNotSupportedException {
    extreme_value o = (extreme_value) super.clone();
    o.datatime = (o.datatime != null) ? (java.sql.Timestamp) o.datatime.clone() : null;
    return o;
  }

  public void clone0(extreme_value o) throws CloneNotSupportedException {
    o.datatime = (o.datatime != null) ? (java.sql.Timestamp) o.datatime.clone() : null;
  }

  public Map<String, Object> getFieldMap() {
    Map<String, Object> __sqoop$field_map = new TreeMap<String, Object>();
    __sqoop$field_map.put("orgseq", this.orgseq);
    __sqoop$field_map.put("vehiclemodelseq", this.vehiclemodelseq);
    __sqoop$field_map.put("vehicleseq", this.vehicleseq);
    __sqoop$field_map.put("districtseq", this.districtseq);
    __sqoop$field_map.put("datatime", this.datatime);
    __sqoop$field_map.put("maxtmpval", this.maxtmpval);
    __sqoop$field_map.put("mintmpval", this.mintmpval);
    __sqoop$field_map.put("maxbatterysinglevoltageval", this.maxbatterysinglevoltageval);
    __sqoop$field_map.put("minbatterysinglevoltageval", this.minbatterysinglevoltageval);
    return __sqoop$field_map;
  }

  public void getFieldMap0(Map<String, Object> __sqoop$field_map) {
    __sqoop$field_map.put("orgseq", this.orgseq);
    __sqoop$field_map.put("vehiclemodelseq", this.vehiclemodelseq);
    __sqoop$field_map.put("vehicleseq", this.vehicleseq);
    __sqoop$field_map.put("districtseq", this.districtseq);
    __sqoop$field_map.put("datatime", this.datatime);
    __sqoop$field_map.put("maxtmpval", this.maxtmpval);
    __sqoop$field_map.put("mintmpval", this.mintmpval);
    __sqoop$field_map.put("maxbatterysinglevoltageval", this.maxbatterysinglevoltageval);
    __sqoop$field_map.put("minbatterysinglevoltageval", this.minbatterysinglevoltageval);
  }

  public void setField(String __fieldName, Object __fieldVal) {
    if ("orgseq".equals(__fieldName)) {
      this.orgseq = (Integer) __fieldVal;
    }
    else    if ("vehiclemodelseq".equals(__fieldName)) {
      this.vehiclemodelseq = (Integer) __fieldVal;
    }
    else    if ("vehicleseq".equals(__fieldName)) {
      this.vehicleseq = (Long) __fieldVal;
    }
    else    if ("districtseq".equals(__fieldName)) {
      this.districtseq = (Integer) __fieldVal;
    }
    else    if ("datatime".equals(__fieldName)) {
      this.datatime = (java.sql.Timestamp) __fieldVal;
    }
    else    if ("maxtmpval".equals(__fieldName)) {
      this.maxtmpval = (Integer) __fieldVal;
    }
    else    if ("mintmpval".equals(__fieldName)) {
      this.mintmpval = (Integer) __fieldVal;
    }
    else    if ("maxbatterysinglevoltageval".equals(__fieldName)) {
      this.maxbatterysinglevoltageval = (Double) __fieldVal;
    }
    else    if ("minbatterysinglevoltageval".equals(__fieldName)) {
      this.minbatterysinglevoltageval = (Double) __fieldVal;
    }
    else {
      throw new RuntimeException("No such field: " + __fieldName);
    }
  }
  public boolean setField0(String __fieldName, Object __fieldVal) {
    if ("orgseq".equals(__fieldName)) {
      this.orgseq = (Integer) __fieldVal;
      return true;
    }
    else    if ("vehiclemodelseq".equals(__fieldName)) {
      this.vehiclemodelseq = (Integer) __fieldVal;
      return true;
    }
    else    if ("vehicleseq".equals(__fieldName)) {
      this.vehicleseq = (Long) __fieldVal;
      return true;
    }
    else    if ("districtseq".equals(__fieldName)) {
      this.districtseq = (Integer) __fieldVal;
      return true;
    }
    else    if ("datatime".equals(__fieldName)) {
      this.datatime = (java.sql.Timestamp) __fieldVal;
      return true;
    }
    else    if ("maxtmpval".equals(__fieldName)) {
      this.maxtmpval = (Integer) __fieldVal;
      return true;
    }
    else    if ("mintmpval".equals(__fieldName)) {
      this.mintmpval = (Integer) __fieldVal;
      return true;
    }
    else    if ("maxbatterysinglevoltageval".equals(__fieldName)) {
      this.maxbatterysinglevoltageval = (Double) __fieldVal;
      return true;
    }
    else    if ("minbatterysinglevoltageval".equals(__fieldName)) {
      this.minbatterysinglevoltageval = (Double) __fieldVal;
      return true;
    }
    else {
      return false;    }
  }
}
