#!/bin/bash

echo "====================== begin battery mr ! ======================="

hadoop jar /root/app/evcard.jar com.extrame.data.process.hbase.mr.BatteryMr

echo "======================  end battery mr !  ======================="



echo "====================== begin alarm mr ! ======================="

hadoop jar /root/app/evcard.jar com.extrame.data.process.hbase.mr.AlarmMr

echo "======================  end alarm mr !  ======================="
