insert overwrite table alarm_data_hive
select
orgseq,
vehiclemodelseq,
vehicleseq,
districtseq,
datatime,
maxalarmlevel,
comalarmflag,
sumrechargeablestoragefaults,
rechargeablestoragefaultscodelist,
sumdrivemotorfaults,
drivemotorfaultscodelist,
sumenginefaults,
enginefaultslist,
sumothersfaults,
othersfaultscodelist
from alarm_data;

insert overwrite table dibiao_add_data_hive
select
orgseq,
vehiclemodelseq,
vehicleseq,
districtseq,
datatime,
startFireTime,
endFireTime,
direction,
acceleratorPedal,
brakeStatus,
powerSystemReady,
emergencyPowerDown,
highVoltageCurrent,
remainingBattery,
batteryPowerSum,
balanceActivated,
tmppakage,
tmppakagelist
from dibiao_add_data;
