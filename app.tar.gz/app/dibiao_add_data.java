// ORM class for table 'dibiao_add_data'
// WARNING: This class is AUTO-GENERATED. Modify at your own risk.
//
// Debug information:
// Generated date: Sun Jan 28 22:28:24 CST 2018
// For connector: org.apache.sqoop.manager.MySQLManager
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapred.lib.db.DBWritable;
import com.cloudera.sqoop.lib.JdbcWritableBridge;
import com.cloudera.sqoop.lib.DelimiterSet;
import com.cloudera.sqoop.lib.FieldFormatter;
import com.cloudera.sqoop.lib.RecordParser;
import com.cloudera.sqoop.lib.BooleanParser;
import com.cloudera.sqoop.lib.BlobRef;
import com.cloudera.sqoop.lib.ClobRef;
import com.cloudera.sqoop.lib.LargeObjectLoader;
import com.cloudera.sqoop.lib.SqoopRecord;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class dibiao_add_data extends SqoopRecord  implements DBWritable, Writable {
  private final int PROTOCOL_VERSION = 3;
  public int getClassFormatVersion() { return PROTOCOL_VERSION; }
  protected ResultSet __cur_result_set;
  private Integer orgseq;
  public Integer get_orgseq() {
    return orgseq;
  }
  public void set_orgseq(Integer orgseq) {
    this.orgseq = orgseq;
  }
  public dibiao_add_data with_orgseq(Integer orgseq) {
    this.orgseq = orgseq;
    return this;
  }
  private Integer vehiclemodelseq;
  public Integer get_vehiclemodelseq() {
    return vehiclemodelseq;
  }
  public void set_vehiclemodelseq(Integer vehiclemodelseq) {
    this.vehiclemodelseq = vehiclemodelseq;
  }
  public dibiao_add_data with_vehiclemodelseq(Integer vehiclemodelseq) {
    this.vehiclemodelseq = vehiclemodelseq;
    return this;
  }
  private Long vehicleseq;
  public Long get_vehicleseq() {
    return vehicleseq;
  }
  public void set_vehicleseq(Long vehicleseq) {
    this.vehicleseq = vehicleseq;
  }
  public dibiao_add_data with_vehicleseq(Long vehicleseq) {
    this.vehicleseq = vehicleseq;
    return this;
  }
  private Integer districtseq;
  public Integer get_districtseq() {
    return districtseq;
  }
  public void set_districtseq(Integer districtseq) {
    this.districtseq = districtseq;
  }
  public dibiao_add_data with_districtseq(Integer districtseq) {
    this.districtseq = districtseq;
    return this;
  }
  private java.sql.Timestamp datatime;
  public java.sql.Timestamp get_datatime() {
    return datatime;
  }
  public void set_datatime(java.sql.Timestamp datatime) {
    this.datatime = datatime;
  }
  public dibiao_add_data with_datatime(java.sql.Timestamp datatime) {
    this.datatime = datatime;
    return this;
  }
  private java.sql.Timestamp startfiretime;
  public java.sql.Timestamp get_startfiretime() {
    return startfiretime;
  }
  public void set_startfiretime(java.sql.Timestamp startfiretime) {
    this.startfiretime = startfiretime;
  }
  public dibiao_add_data with_startfiretime(java.sql.Timestamp startfiretime) {
    this.startfiretime = startfiretime;
    return this;
  }
  private java.sql.Timestamp endfiretime;
  public java.sql.Timestamp get_endfiretime() {
    return endfiretime;
  }
  public void set_endfiretime(java.sql.Timestamp endfiretime) {
    this.endfiretime = endfiretime;
  }
  public dibiao_add_data with_endfiretime(java.sql.Timestamp endfiretime) {
    this.endfiretime = endfiretime;
    return this;
  }
  private Integer direction;
  public Integer get_direction() {
    return direction;
  }
  public void set_direction(Integer direction) {
    this.direction = direction;
  }
  public dibiao_add_data with_direction(Integer direction) {
    this.direction = direction;
    return this;
  }
  private Integer acceleratorpedal;
  public Integer get_acceleratorpedal() {
    return acceleratorpedal;
  }
  public void set_acceleratorpedal(Integer acceleratorpedal) {
    this.acceleratorpedal = acceleratorpedal;
  }
  public dibiao_add_data with_acceleratorpedal(Integer acceleratorpedal) {
    this.acceleratorpedal = acceleratorpedal;
    return this;
  }
  private Integer brakestatus;
  public Integer get_brakestatus() {
    return brakestatus;
  }
  public void set_brakestatus(Integer brakestatus) {
    this.brakestatus = brakestatus;
  }
  public dibiao_add_data with_brakestatus(Integer brakestatus) {
    this.brakestatus = brakestatus;
    return this;
  }
  private Integer powersystemready;
  public Integer get_powersystemready() {
    return powersystemready;
  }
  public void set_powersystemready(Integer powersystemready) {
    this.powersystemready = powersystemready;
  }
  public dibiao_add_data with_powersystemready(Integer powersystemready) {
    this.powersystemready = powersystemready;
    return this;
  }
  private Integer emergencypowerdown;
  public Integer get_emergencypowerdown() {
    return emergencypowerdown;
  }
  public void set_emergencypowerdown(Integer emergencypowerdown) {
    this.emergencypowerdown = emergencypowerdown;
  }
  public dibiao_add_data with_emergencypowerdown(Integer emergencypowerdown) {
    this.emergencypowerdown = emergencypowerdown;
    return this;
  }
  private Double highvoltagecurrent;
  public Double get_highvoltagecurrent() {
    return highvoltagecurrent;
  }
  public void set_highvoltagecurrent(Double highvoltagecurrent) {
    this.highvoltagecurrent = highvoltagecurrent;
  }
  public dibiao_add_data with_highvoltagecurrent(Double highvoltagecurrent) {
    this.highvoltagecurrent = highvoltagecurrent;
    return this;
  }
  private Double remainingbattery;
  public Double get_remainingbattery() {
    return remainingbattery;
  }
  public void set_remainingbattery(Double remainingbattery) {
    this.remainingbattery = remainingbattery;
  }
  public dibiao_add_data with_remainingbattery(Double remainingbattery) {
    this.remainingbattery = remainingbattery;
    return this;
  }
  private Double batterypowersum;
  public Double get_batterypowersum() {
    return batterypowersum;
  }
  public void set_batterypowersum(Double batterypowersum) {
    this.batterypowersum = batterypowersum;
  }
  public dibiao_add_data with_batterypowersum(Double batterypowersum) {
    this.batterypowersum = batterypowersum;
    return this;
  }
  private Integer balanceactivated;
  public Integer get_balanceactivated() {
    return balanceactivated;
  }
  public void set_balanceactivated(Integer balanceactivated) {
    this.balanceactivated = balanceactivated;
  }
  public dibiao_add_data with_balanceactivated(Integer balanceactivated) {
    this.balanceactivated = balanceactivated;
    return this;
  }
  private Integer tmppakage;
  public Integer get_tmppakage() {
    return tmppakage;
  }
  public void set_tmppakage(Integer tmppakage) {
    this.tmppakage = tmppakage;
  }
  public dibiao_add_data with_tmppakage(Integer tmppakage) {
    this.tmppakage = tmppakage;
    return this;
  }
  private String tmppakagelist;
  public String get_tmppakagelist() {
    return tmppakagelist;
  }
  public void set_tmppakagelist(String tmppakagelist) {
    this.tmppakagelist = tmppakagelist;
  }
  public dibiao_add_data with_tmppakagelist(String tmppakagelist) {
    this.tmppakagelist = tmppakagelist;
    return this;
  }
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof dibiao_add_data)) {
      return false;
    }
    dibiao_add_data that = (dibiao_add_data) o;
    boolean equal = true;
    equal = equal && (this.orgseq == null ? that.orgseq == null : this.orgseq.equals(that.orgseq));
    equal = equal && (this.vehiclemodelseq == null ? that.vehiclemodelseq == null : this.vehiclemodelseq.equals(that.vehiclemodelseq));
    equal = equal && (this.vehicleseq == null ? that.vehicleseq == null : this.vehicleseq.equals(that.vehicleseq));
    equal = equal && (this.districtseq == null ? that.districtseq == null : this.districtseq.equals(that.districtseq));
    equal = equal && (this.datatime == null ? that.datatime == null : this.datatime.equals(that.datatime));
    equal = equal && (this.startfiretime == null ? that.startfiretime == null : this.startfiretime.equals(that.startfiretime));
    equal = equal && (this.endfiretime == null ? that.endfiretime == null : this.endfiretime.equals(that.endfiretime));
    equal = equal && (this.direction == null ? that.direction == null : this.direction.equals(that.direction));
    equal = equal && (this.acceleratorpedal == null ? that.acceleratorpedal == null : this.acceleratorpedal.equals(that.acceleratorpedal));
    equal = equal && (this.brakestatus == null ? that.brakestatus == null : this.brakestatus.equals(that.brakestatus));
    equal = equal && (this.powersystemready == null ? that.powersystemready == null : this.powersystemready.equals(that.powersystemready));
    equal = equal && (this.emergencypowerdown == null ? that.emergencypowerdown == null : this.emergencypowerdown.equals(that.emergencypowerdown));
    equal = equal && (this.highvoltagecurrent == null ? that.highvoltagecurrent == null : this.highvoltagecurrent.equals(that.highvoltagecurrent));
    equal = equal && (this.remainingbattery == null ? that.remainingbattery == null : this.remainingbattery.equals(that.remainingbattery));
    equal = equal && (this.batterypowersum == null ? that.batterypowersum == null : this.batterypowersum.equals(that.batterypowersum));
    equal = equal && (this.balanceactivated == null ? that.balanceactivated == null : this.balanceactivated.equals(that.balanceactivated));
    equal = equal && (this.tmppakage == null ? that.tmppakage == null : this.tmppakage.equals(that.tmppakage));
    equal = equal && (this.tmppakagelist == null ? that.tmppakagelist == null : this.tmppakagelist.equals(that.tmppakagelist));
    return equal;
  }
  public boolean equals0(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof dibiao_add_data)) {
      return false;
    }
    dibiao_add_data that = (dibiao_add_data) o;
    boolean equal = true;
    equal = equal && (this.orgseq == null ? that.orgseq == null : this.orgseq.equals(that.orgseq));
    equal = equal && (this.vehiclemodelseq == null ? that.vehiclemodelseq == null : this.vehiclemodelseq.equals(that.vehiclemodelseq));
    equal = equal && (this.vehicleseq == null ? that.vehicleseq == null : this.vehicleseq.equals(that.vehicleseq));
    equal = equal && (this.districtseq == null ? that.districtseq == null : this.districtseq.equals(that.districtseq));
    equal = equal && (this.datatime == null ? that.datatime == null : this.datatime.equals(that.datatime));
    equal = equal && (this.startfiretime == null ? that.startfiretime == null : this.startfiretime.equals(that.startfiretime));
    equal = equal && (this.endfiretime == null ? that.endfiretime == null : this.endfiretime.equals(that.endfiretime));
    equal = equal && (this.direction == null ? that.direction == null : this.direction.equals(that.direction));
    equal = equal && (this.acceleratorpedal == null ? that.acceleratorpedal == null : this.acceleratorpedal.equals(that.acceleratorpedal));
    equal = equal && (this.brakestatus == null ? that.brakestatus == null : this.brakestatus.equals(that.brakestatus));
    equal = equal && (this.powersystemready == null ? that.powersystemready == null : this.powersystemready.equals(that.powersystemready));
    equal = equal && (this.emergencypowerdown == null ? that.emergencypowerdown == null : this.emergencypowerdown.equals(that.emergencypowerdown));
    equal = equal && (this.highvoltagecurrent == null ? that.highvoltagecurrent == null : this.highvoltagecurrent.equals(that.highvoltagecurrent));
    equal = equal && (this.remainingbattery == null ? that.remainingbattery == null : this.remainingbattery.equals(that.remainingbattery));
    equal = equal && (this.batterypowersum == null ? that.batterypowersum == null : this.batterypowersum.equals(that.batterypowersum));
    equal = equal && (this.balanceactivated == null ? that.balanceactivated == null : this.balanceactivated.equals(that.balanceactivated));
    equal = equal && (this.tmppakage == null ? that.tmppakage == null : this.tmppakage.equals(that.tmppakage));
    equal = equal && (this.tmppakagelist == null ? that.tmppakagelist == null : this.tmppakagelist.equals(that.tmppakagelist));
    return equal;
  }
  public void readFields(ResultSet __dbResults) throws SQLException {
    this.__cur_result_set = __dbResults;
    this.orgseq = JdbcWritableBridge.readInteger(1, __dbResults);
    this.vehiclemodelseq = JdbcWritableBridge.readInteger(2, __dbResults);
    this.vehicleseq = JdbcWritableBridge.readLong(3, __dbResults);
    this.districtseq = JdbcWritableBridge.readInteger(4, __dbResults);
    this.datatime = JdbcWritableBridge.readTimestamp(5, __dbResults);
    this.startfiretime = JdbcWritableBridge.readTimestamp(6, __dbResults);
    this.endfiretime = JdbcWritableBridge.readTimestamp(7, __dbResults);
    this.direction = JdbcWritableBridge.readInteger(8, __dbResults);
    this.acceleratorpedal = JdbcWritableBridge.readInteger(9, __dbResults);
    this.brakestatus = JdbcWritableBridge.readInteger(10, __dbResults);
    this.powersystemready = JdbcWritableBridge.readInteger(11, __dbResults);
    this.emergencypowerdown = JdbcWritableBridge.readInteger(12, __dbResults);
    this.highvoltagecurrent = JdbcWritableBridge.readDouble(13, __dbResults);
    this.remainingbattery = JdbcWritableBridge.readDouble(14, __dbResults);
    this.batterypowersum = JdbcWritableBridge.readDouble(15, __dbResults);
    this.balanceactivated = JdbcWritableBridge.readInteger(16, __dbResults);
    this.tmppakage = JdbcWritableBridge.readInteger(17, __dbResults);
    this.tmppakagelist = JdbcWritableBridge.readString(18, __dbResults);
  }
  public void readFields0(ResultSet __dbResults) throws SQLException {
    this.orgseq = JdbcWritableBridge.readInteger(1, __dbResults);
    this.vehiclemodelseq = JdbcWritableBridge.readInteger(2, __dbResults);
    this.vehicleseq = JdbcWritableBridge.readLong(3, __dbResults);
    this.districtseq = JdbcWritableBridge.readInteger(4, __dbResults);
    this.datatime = JdbcWritableBridge.readTimestamp(5, __dbResults);
    this.startfiretime = JdbcWritableBridge.readTimestamp(6, __dbResults);
    this.endfiretime = JdbcWritableBridge.readTimestamp(7, __dbResults);
    this.direction = JdbcWritableBridge.readInteger(8, __dbResults);
    this.acceleratorpedal = JdbcWritableBridge.readInteger(9, __dbResults);
    this.brakestatus = JdbcWritableBridge.readInteger(10, __dbResults);
    this.powersystemready = JdbcWritableBridge.readInteger(11, __dbResults);
    this.emergencypowerdown = JdbcWritableBridge.readInteger(12, __dbResults);
    this.highvoltagecurrent = JdbcWritableBridge.readDouble(13, __dbResults);
    this.remainingbattery = JdbcWritableBridge.readDouble(14, __dbResults);
    this.batterypowersum = JdbcWritableBridge.readDouble(15, __dbResults);
    this.balanceactivated = JdbcWritableBridge.readInteger(16, __dbResults);
    this.tmppakage = JdbcWritableBridge.readInteger(17, __dbResults);
    this.tmppakagelist = JdbcWritableBridge.readString(18, __dbResults);
  }
  public void loadLargeObjects(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void loadLargeObjects0(LargeObjectLoader __loader)
      throws SQLException, IOException, InterruptedException {
  }
  public void write(PreparedStatement __dbStmt) throws SQLException {
    write(__dbStmt, 0);
  }

  public int write(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeInteger(orgseq, 1 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(vehiclemodelseq, 2 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeLong(vehicleseq, 3 + __off, -5, __dbStmt);
    JdbcWritableBridge.writeInteger(districtseq, 4 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeTimestamp(datatime, 5 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(startfiretime, 6 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(endfiretime, 7 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeInteger(direction, 8 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(acceleratorpedal, 9 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(brakestatus, 10 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(powersystemready, 11 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(emergencypowerdown, 12 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeDouble(highvoltagecurrent, 13 + __off, 8, __dbStmt);
    JdbcWritableBridge.writeDouble(remainingbattery, 14 + __off, 8, __dbStmt);
    JdbcWritableBridge.writeDouble(batterypowersum, 15 + __off, 8, __dbStmt);
    JdbcWritableBridge.writeInteger(balanceactivated, 16 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(tmppakage, 17 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeString(tmppakagelist, 18 + __off, 12, __dbStmt);
    return 18;
  }
  public void write0(PreparedStatement __dbStmt, int __off) throws SQLException {
    JdbcWritableBridge.writeInteger(orgseq, 1 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(vehiclemodelseq, 2 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeLong(vehicleseq, 3 + __off, -5, __dbStmt);
    JdbcWritableBridge.writeInteger(districtseq, 4 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeTimestamp(datatime, 5 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(startfiretime, 6 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeTimestamp(endfiretime, 7 + __off, 93, __dbStmt);
    JdbcWritableBridge.writeInteger(direction, 8 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(acceleratorpedal, 9 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(brakestatus, 10 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(powersystemready, 11 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(emergencypowerdown, 12 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeDouble(highvoltagecurrent, 13 + __off, 8, __dbStmt);
    JdbcWritableBridge.writeDouble(remainingbattery, 14 + __off, 8, __dbStmt);
    JdbcWritableBridge.writeDouble(batterypowersum, 15 + __off, 8, __dbStmt);
    JdbcWritableBridge.writeInteger(balanceactivated, 16 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeInteger(tmppakage, 17 + __off, 4, __dbStmt);
    JdbcWritableBridge.writeString(tmppakagelist, 18 + __off, 12, __dbStmt);
  }
  public void readFields(DataInput __dataIn) throws IOException {
this.readFields0(__dataIn);  }
  public void readFields0(DataInput __dataIn) throws IOException {
    if (__dataIn.readBoolean()) { 
        this.orgseq = null;
    } else {
    this.orgseq = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.vehiclemodelseq = null;
    } else {
    this.vehiclemodelseq = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.vehicleseq = null;
    } else {
    this.vehicleseq = Long.valueOf(__dataIn.readLong());
    }
    if (__dataIn.readBoolean()) { 
        this.districtseq = null;
    } else {
    this.districtseq = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.datatime = null;
    } else {
    this.datatime = new Timestamp(__dataIn.readLong());
    this.datatime.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.startfiretime = null;
    } else {
    this.startfiretime = new Timestamp(__dataIn.readLong());
    this.startfiretime.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.endfiretime = null;
    } else {
    this.endfiretime = new Timestamp(__dataIn.readLong());
    this.endfiretime.setNanos(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.direction = null;
    } else {
    this.direction = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.acceleratorpedal = null;
    } else {
    this.acceleratorpedal = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.brakestatus = null;
    } else {
    this.brakestatus = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.powersystemready = null;
    } else {
    this.powersystemready = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.emergencypowerdown = null;
    } else {
    this.emergencypowerdown = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.highvoltagecurrent = null;
    } else {
    this.highvoltagecurrent = Double.valueOf(__dataIn.readDouble());
    }
    if (__dataIn.readBoolean()) { 
        this.remainingbattery = null;
    } else {
    this.remainingbattery = Double.valueOf(__dataIn.readDouble());
    }
    if (__dataIn.readBoolean()) { 
        this.batterypowersum = null;
    } else {
    this.batterypowersum = Double.valueOf(__dataIn.readDouble());
    }
    if (__dataIn.readBoolean()) { 
        this.balanceactivated = null;
    } else {
    this.balanceactivated = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.tmppakage = null;
    } else {
    this.tmppakage = Integer.valueOf(__dataIn.readInt());
    }
    if (__dataIn.readBoolean()) { 
        this.tmppakagelist = null;
    } else {
    this.tmppakagelist = Text.readString(__dataIn);
    }
  }
  public void write(DataOutput __dataOut) throws IOException {
    if (null == this.orgseq) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.orgseq);
    }
    if (null == this.vehiclemodelseq) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.vehiclemodelseq);
    }
    if (null == this.vehicleseq) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.vehicleseq);
    }
    if (null == this.districtseq) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.districtseq);
    }
    if (null == this.datatime) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.datatime.getTime());
    __dataOut.writeInt(this.datatime.getNanos());
    }
    if (null == this.startfiretime) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.startfiretime.getTime());
    __dataOut.writeInt(this.startfiretime.getNanos());
    }
    if (null == this.endfiretime) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.endfiretime.getTime());
    __dataOut.writeInt(this.endfiretime.getNanos());
    }
    if (null == this.direction) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.direction);
    }
    if (null == this.acceleratorpedal) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.acceleratorpedal);
    }
    if (null == this.brakestatus) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.brakestatus);
    }
    if (null == this.powersystemready) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.powersystemready);
    }
    if (null == this.emergencypowerdown) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.emergencypowerdown);
    }
    if (null == this.highvoltagecurrent) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeDouble(this.highvoltagecurrent);
    }
    if (null == this.remainingbattery) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeDouble(this.remainingbattery);
    }
    if (null == this.batterypowersum) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeDouble(this.batterypowersum);
    }
    if (null == this.balanceactivated) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.balanceactivated);
    }
    if (null == this.tmppakage) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.tmppakage);
    }
    if (null == this.tmppakagelist) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, tmppakagelist);
    }
  }
  public void write0(DataOutput __dataOut) throws IOException {
    if (null == this.orgseq) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.orgseq);
    }
    if (null == this.vehiclemodelseq) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.vehiclemodelseq);
    }
    if (null == this.vehicleseq) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.vehicleseq);
    }
    if (null == this.districtseq) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.districtseq);
    }
    if (null == this.datatime) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.datatime.getTime());
    __dataOut.writeInt(this.datatime.getNanos());
    }
    if (null == this.startfiretime) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.startfiretime.getTime());
    __dataOut.writeInt(this.startfiretime.getNanos());
    }
    if (null == this.endfiretime) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeLong(this.endfiretime.getTime());
    __dataOut.writeInt(this.endfiretime.getNanos());
    }
    if (null == this.direction) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.direction);
    }
    if (null == this.acceleratorpedal) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.acceleratorpedal);
    }
    if (null == this.brakestatus) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.brakestatus);
    }
    if (null == this.powersystemready) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.powersystemready);
    }
    if (null == this.emergencypowerdown) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.emergencypowerdown);
    }
    if (null == this.highvoltagecurrent) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeDouble(this.highvoltagecurrent);
    }
    if (null == this.remainingbattery) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeDouble(this.remainingbattery);
    }
    if (null == this.batterypowersum) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeDouble(this.batterypowersum);
    }
    if (null == this.balanceactivated) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.balanceactivated);
    }
    if (null == this.tmppakage) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    __dataOut.writeInt(this.tmppakage);
    }
    if (null == this.tmppakagelist) { 
        __dataOut.writeBoolean(true);
    } else {
        __dataOut.writeBoolean(false);
    Text.writeString(__dataOut, tmppakagelist);
    }
  }
  private static final DelimiterSet __outputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  public String toString() {
    return toString(__outputDelimiters, true);
  }
  public String toString(DelimiterSet delimiters) {
    return toString(delimiters, true);
  }
  public String toString(boolean useRecordDelim) {
    return toString(__outputDelimiters, useRecordDelim);
  }
  public String toString(DelimiterSet delimiters, boolean useRecordDelim) {
    StringBuilder __sb = new StringBuilder();
    char fieldDelim = delimiters.getFieldsTerminatedBy();
    __sb.append(FieldFormatter.escapeAndEnclose(orgseq==null?"null":"" + orgseq, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(vehiclemodelseq==null?"null":"" + vehiclemodelseq, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(vehicleseq==null?"null":"" + vehicleseq, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(districtseq==null?"null":"" + districtseq, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(datatime==null?"null":"" + datatime, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(startfiretime==null?"null":"" + startfiretime, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(endfiretime==null?"null":"" + endfiretime, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(direction==null?"null":"" + direction, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(acceleratorpedal==null?"null":"" + acceleratorpedal, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(brakestatus==null?"null":"" + brakestatus, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(powersystemready==null?"null":"" + powersystemready, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(emergencypowerdown==null?"null":"" + emergencypowerdown, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(highvoltagecurrent==null?"null":"" + highvoltagecurrent, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(remainingbattery==null?"null":"" + remainingbattery, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(batterypowersum==null?"null":"" + batterypowersum, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(balanceactivated==null?"null":"" + balanceactivated, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(tmppakage==null?"null":"" + tmppakage, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(tmppakagelist==null?"null":tmppakagelist, delimiters));
    if (useRecordDelim) {
      __sb.append(delimiters.getLinesTerminatedBy());
    }
    return __sb.toString();
  }
  public void toString0(DelimiterSet delimiters, StringBuilder __sb, char fieldDelim) {
    __sb.append(FieldFormatter.escapeAndEnclose(orgseq==null?"null":"" + orgseq, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(vehiclemodelseq==null?"null":"" + vehiclemodelseq, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(vehicleseq==null?"null":"" + vehicleseq, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(districtseq==null?"null":"" + districtseq, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(datatime==null?"null":"" + datatime, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(startfiretime==null?"null":"" + startfiretime, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(endfiretime==null?"null":"" + endfiretime, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(direction==null?"null":"" + direction, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(acceleratorpedal==null?"null":"" + acceleratorpedal, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(brakestatus==null?"null":"" + brakestatus, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(powersystemready==null?"null":"" + powersystemready, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(emergencypowerdown==null?"null":"" + emergencypowerdown, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(highvoltagecurrent==null?"null":"" + highvoltagecurrent, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(remainingbattery==null?"null":"" + remainingbattery, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(batterypowersum==null?"null":"" + batterypowersum, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(balanceactivated==null?"null":"" + balanceactivated, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(tmppakage==null?"null":"" + tmppakage, delimiters));
    __sb.append(fieldDelim);
    __sb.append(FieldFormatter.escapeAndEnclose(tmppakagelist==null?"null":tmppakagelist, delimiters));
  }
  private static final DelimiterSet __inputDelimiters = new DelimiterSet((char) 1, (char) 10, (char) 0, (char) 0, false);
  private RecordParser __parser;
  public void parse(Text __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharSequence __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(byte [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(char [] __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(ByteBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  public void parse(CharBuffer __record) throws RecordParser.ParseError {
    if (null == this.__parser) {
      this.__parser = new RecordParser(__inputDelimiters);
    }
    List<String> __fields = this.__parser.parseRecord(__record);
    __loadFromFields(__fields);
  }

  private void __loadFromFields(List<String> fields) {
    Iterator<String> __it = fields.listIterator();
    String __cur_str = null;
    try {
    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.orgseq = null; } else {
      this.orgseq = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.vehiclemodelseq = null; } else {
      this.vehiclemodelseq = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.vehicleseq = null; } else {
      this.vehicleseq = Long.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.districtseq = null; } else {
      this.districtseq = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.datatime = null; } else {
      this.datatime = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.startfiretime = null; } else {
      this.startfiretime = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.endfiretime = null; } else {
      this.endfiretime = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.direction = null; } else {
      this.direction = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.acceleratorpedal = null; } else {
      this.acceleratorpedal = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.brakestatus = null; } else {
      this.brakestatus = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.powersystemready = null; } else {
      this.powersystemready = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.emergencypowerdown = null; } else {
      this.emergencypowerdown = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.highvoltagecurrent = null; } else {
      this.highvoltagecurrent = Double.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.remainingbattery = null; } else {
      this.remainingbattery = Double.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.batterypowersum = null; } else {
      this.batterypowersum = Double.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.balanceactivated = null; } else {
      this.balanceactivated = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.tmppakage = null; } else {
      this.tmppakage = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N")) { this.tmppakagelist = null; } else {
      this.tmppakagelist = __cur_str;
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  private void __loadFromFields0(Iterator<String> __it) {
    String __cur_str = null;
    try {
    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.orgseq = null; } else {
      this.orgseq = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.vehiclemodelseq = null; } else {
      this.vehiclemodelseq = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.vehicleseq = null; } else {
      this.vehicleseq = Long.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.districtseq = null; } else {
      this.districtseq = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.datatime = null; } else {
      this.datatime = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.startfiretime = null; } else {
      this.startfiretime = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.endfiretime = null; } else {
      this.endfiretime = java.sql.Timestamp.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.direction = null; } else {
      this.direction = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.acceleratorpedal = null; } else {
      this.acceleratorpedal = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.brakestatus = null; } else {
      this.brakestatus = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.powersystemready = null; } else {
      this.powersystemready = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.emergencypowerdown = null; } else {
      this.emergencypowerdown = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.highvoltagecurrent = null; } else {
      this.highvoltagecurrent = Double.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.remainingbattery = null; } else {
      this.remainingbattery = Double.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.batterypowersum = null; } else {
      this.batterypowersum = Double.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.balanceactivated = null; } else {
      this.balanceactivated = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N") || __cur_str.length() == 0) { this.tmppakage = null; } else {
      this.tmppakage = Integer.valueOf(__cur_str);
    }

    __cur_str = __it.next();
    if (__cur_str.equals("\\N")) { this.tmppakagelist = null; } else {
      this.tmppakagelist = __cur_str;
    }

    } catch (RuntimeException e) {    throw new RuntimeException("Can't parse input data: '" + __cur_str + "'", e);    }  }

  public Object clone() throws CloneNotSupportedException {
    dibiao_add_data o = (dibiao_add_data) super.clone();
    o.datatime = (o.datatime != null) ? (java.sql.Timestamp) o.datatime.clone() : null;
    o.startfiretime = (o.startfiretime != null) ? (java.sql.Timestamp) o.startfiretime.clone() : null;
    o.endfiretime = (o.endfiretime != null) ? (java.sql.Timestamp) o.endfiretime.clone() : null;
    return o;
  }

  public void clone0(dibiao_add_data o) throws CloneNotSupportedException {
    o.datatime = (o.datatime != null) ? (java.sql.Timestamp) o.datatime.clone() : null;
    o.startfiretime = (o.startfiretime != null) ? (java.sql.Timestamp) o.startfiretime.clone() : null;
    o.endfiretime = (o.endfiretime != null) ? (java.sql.Timestamp) o.endfiretime.clone() : null;
  }

  public Map<String, Object> getFieldMap() {
    Map<String, Object> __sqoop$field_map = new TreeMap<String, Object>();
    __sqoop$field_map.put("orgseq", this.orgseq);
    __sqoop$field_map.put("vehiclemodelseq", this.vehiclemodelseq);
    __sqoop$field_map.put("vehicleseq", this.vehicleseq);
    __sqoop$field_map.put("districtseq", this.districtseq);
    __sqoop$field_map.put("datatime", this.datatime);
    __sqoop$field_map.put("startfiretime", this.startfiretime);
    __sqoop$field_map.put("endfiretime", this.endfiretime);
    __sqoop$field_map.put("direction", this.direction);
    __sqoop$field_map.put("acceleratorpedal", this.acceleratorpedal);
    __sqoop$field_map.put("brakestatus", this.brakestatus);
    __sqoop$field_map.put("powersystemready", this.powersystemready);
    __sqoop$field_map.put("emergencypowerdown", this.emergencypowerdown);
    __sqoop$field_map.put("highvoltagecurrent", this.highvoltagecurrent);
    __sqoop$field_map.put("remainingbattery", this.remainingbattery);
    __sqoop$field_map.put("batterypowersum", this.batterypowersum);
    __sqoop$field_map.put("balanceactivated", this.balanceactivated);
    __sqoop$field_map.put("tmppakage", this.tmppakage);
    __sqoop$field_map.put("tmppakagelist", this.tmppakagelist);
    return __sqoop$field_map;
  }

  public void getFieldMap0(Map<String, Object> __sqoop$field_map) {
    __sqoop$field_map.put("orgseq", this.orgseq);
    __sqoop$field_map.put("vehiclemodelseq", this.vehiclemodelseq);
    __sqoop$field_map.put("vehicleseq", this.vehicleseq);
    __sqoop$field_map.put("districtseq", this.districtseq);
    __sqoop$field_map.put("datatime", this.datatime);
    __sqoop$field_map.put("startfiretime", this.startfiretime);
    __sqoop$field_map.put("endfiretime", this.endfiretime);
    __sqoop$field_map.put("direction", this.direction);
    __sqoop$field_map.put("acceleratorpedal", this.acceleratorpedal);
    __sqoop$field_map.put("brakestatus", this.brakestatus);
    __sqoop$field_map.put("powersystemready", this.powersystemready);
    __sqoop$field_map.put("emergencypowerdown", this.emergencypowerdown);
    __sqoop$field_map.put("highvoltagecurrent", this.highvoltagecurrent);
    __sqoop$field_map.put("remainingbattery", this.remainingbattery);
    __sqoop$field_map.put("batterypowersum", this.batterypowersum);
    __sqoop$field_map.put("balanceactivated", this.balanceactivated);
    __sqoop$field_map.put("tmppakage", this.tmppakage);
    __sqoop$field_map.put("tmppakagelist", this.tmppakagelist);
  }

  public void setField(String __fieldName, Object __fieldVal) {
    if ("orgseq".equals(__fieldName)) {
      this.orgseq = (Integer) __fieldVal;
    }
    else    if ("vehiclemodelseq".equals(__fieldName)) {
      this.vehiclemodelseq = (Integer) __fieldVal;
    }
    else    if ("vehicleseq".equals(__fieldName)) {
      this.vehicleseq = (Long) __fieldVal;
    }
    else    if ("districtseq".equals(__fieldName)) {
      this.districtseq = (Integer) __fieldVal;
    }
    else    if ("datatime".equals(__fieldName)) {
      this.datatime = (java.sql.Timestamp) __fieldVal;
    }
    else    if ("startfiretime".equals(__fieldName)) {
      this.startfiretime = (java.sql.Timestamp) __fieldVal;
    }
    else    if ("endfiretime".equals(__fieldName)) {
      this.endfiretime = (java.sql.Timestamp) __fieldVal;
    }
    else    if ("direction".equals(__fieldName)) {
      this.direction = (Integer) __fieldVal;
    }
    else    if ("acceleratorpedal".equals(__fieldName)) {
      this.acceleratorpedal = (Integer) __fieldVal;
    }
    else    if ("brakestatus".equals(__fieldName)) {
      this.brakestatus = (Integer) __fieldVal;
    }
    else    if ("powersystemready".equals(__fieldName)) {
      this.powersystemready = (Integer) __fieldVal;
    }
    else    if ("emergencypowerdown".equals(__fieldName)) {
      this.emergencypowerdown = (Integer) __fieldVal;
    }
    else    if ("highvoltagecurrent".equals(__fieldName)) {
      this.highvoltagecurrent = (Double) __fieldVal;
    }
    else    if ("remainingbattery".equals(__fieldName)) {
      this.remainingbattery = (Double) __fieldVal;
    }
    else    if ("batterypowersum".equals(__fieldName)) {
      this.batterypowersum = (Double) __fieldVal;
    }
    else    if ("balanceactivated".equals(__fieldName)) {
      this.balanceactivated = (Integer) __fieldVal;
    }
    else    if ("tmppakage".equals(__fieldName)) {
      this.tmppakage = (Integer) __fieldVal;
    }
    else    if ("tmppakagelist".equals(__fieldName)) {
      this.tmppakagelist = (String) __fieldVal;
    }
    else {
      throw new RuntimeException("No such field: " + __fieldName);
    }
  }
  public boolean setField0(String __fieldName, Object __fieldVal) {
    if ("orgseq".equals(__fieldName)) {
      this.orgseq = (Integer) __fieldVal;
      return true;
    }
    else    if ("vehiclemodelseq".equals(__fieldName)) {
      this.vehiclemodelseq = (Integer) __fieldVal;
      return true;
    }
    else    if ("vehicleseq".equals(__fieldName)) {
      this.vehicleseq = (Long) __fieldVal;
      return true;
    }
    else    if ("districtseq".equals(__fieldName)) {
      this.districtseq = (Integer) __fieldVal;
      return true;
    }
    else    if ("datatime".equals(__fieldName)) {
      this.datatime = (java.sql.Timestamp) __fieldVal;
      return true;
    }
    else    if ("startfiretime".equals(__fieldName)) {
      this.startfiretime = (java.sql.Timestamp) __fieldVal;
      return true;
    }
    else    if ("endfiretime".equals(__fieldName)) {
      this.endfiretime = (java.sql.Timestamp) __fieldVal;
      return true;
    }
    else    if ("direction".equals(__fieldName)) {
      this.direction = (Integer) __fieldVal;
      return true;
    }
    else    if ("acceleratorpedal".equals(__fieldName)) {
      this.acceleratorpedal = (Integer) __fieldVal;
      return true;
    }
    else    if ("brakestatus".equals(__fieldName)) {
      this.brakestatus = (Integer) __fieldVal;
      return true;
    }
    else    if ("powersystemready".equals(__fieldName)) {
      this.powersystemready = (Integer) __fieldVal;
      return true;
    }
    else    if ("emergencypowerdown".equals(__fieldName)) {
      this.emergencypowerdown = (Integer) __fieldVal;
      return true;
    }
    else    if ("highvoltagecurrent".equals(__fieldName)) {
      this.highvoltagecurrent = (Double) __fieldVal;
      return true;
    }
    else    if ("remainingbattery".equals(__fieldName)) {
      this.remainingbattery = (Double) __fieldVal;
      return true;
    }
    else    if ("batterypowersum".equals(__fieldName)) {
      this.batterypowersum = (Double) __fieldVal;
      return true;
    }
    else    if ("balanceactivated".equals(__fieldName)) {
      this.balanceactivated = (Integer) __fieldVal;
      return true;
    }
    else    if ("tmppakage".equals(__fieldName)) {
      this.tmppakage = (Integer) __fieldVal;
      return true;
    }
    else    if ("tmppakagelist".equals(__fieldName)) {
      this.tmppakagelist = (String) __fieldVal;
      return true;
    }
    else {
      return false;    }
  }
}
